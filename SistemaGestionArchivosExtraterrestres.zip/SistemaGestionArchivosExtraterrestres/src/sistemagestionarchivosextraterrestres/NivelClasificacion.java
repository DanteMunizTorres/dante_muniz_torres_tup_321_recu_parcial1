/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */


package sistemagestionarchivosextraterrestres;

/**
 *
 * @author Dante
 */
public enum NivelClasificacion {
    PUBLICO,
    RESERVADO,
    ULTRASECRETO
}
