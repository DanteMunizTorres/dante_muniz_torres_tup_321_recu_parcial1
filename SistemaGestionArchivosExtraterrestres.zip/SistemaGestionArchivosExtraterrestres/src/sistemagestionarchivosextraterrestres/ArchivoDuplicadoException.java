package sistemagestionarchivosextraterrestres;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */

/**
 *
 * @author Dante
 */
public class ArchivoDuplicadoException extends Exception {

    /**
     * Creates a new instance of <code>ArchivoDuplicadoException</code> without
     * detail message.
     */
    public static final String MESSAGE = "Ya existe el archivo";
    
    public ArchivoDuplicadoException() {
        this(MESSAGE);
    }

    /**
     * Constructs an instance of <code>ArchivoDuplicadoException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public ArchivoDuplicadoException(String msg) {
        super(msg);
    }
    
    
    

}
