/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package sistemagestionarchivosextraterrestres;
/**
 *
 * @author Dante
 */
public class TestimonioClasificado extends ArchivoDesclasificado implements InformeTecnico {
    
    private String alias;

    public TestimonioClasificado(String codigo, String agenciaResponsable, NivelClasificacion nivelClasificacion, String alias) {
        super(codigo, agenciaResponsable, nivelClasificacion);
        this.alias = alias;
    }

    @Override
    public String generarInforme() {
        return "Informe del testimonio " + this.toString();
    }
    
    
}
