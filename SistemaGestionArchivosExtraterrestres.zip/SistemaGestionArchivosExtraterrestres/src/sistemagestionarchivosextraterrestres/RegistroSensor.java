/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package sistemagestionarchivosextraterrestres;
/**
 *
 * @author Dante
 */
public class RegistroSensor extends EvidenciaTecnica implements InformeTecnico {
    
    private double frecuenciaDetectada;

    public RegistroSensor(String codigo, String agenciaResponsable, NivelClasificacion nivelClasificacion, String fecha, double nivelConfiabilidad, double frecuenciaDetectada) {
        super(codigo, agenciaResponsable, nivelClasificacion, fecha, nivelConfiabilidad);
        this.frecuenciaDetectada = frecuenciaDetectada;
    }
    
    
    
    @Override
    public String generarInforme() {
        return "Informe tecnico del registro " + this.toString();
    }
}
