/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package sistemagestionarchivosextraterrestres;

/**
 *
 * @author Dante
 */
public class ArchivoDesclasificado {
    
    private String codigo;
    private String agenciaResponsable;
    private NivelClasificacion nivelClasificacion;

    public ArchivoDesclasificado(String codigo, String agenciaResponsable, NivelClasificacion nivelClasificacion) {
        this.codigo = codigo;
        this.agenciaResponsable = agenciaResponsable;
        this.nivelClasificacion = nivelClasificacion;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getAgenciaResponsable() {
        return agenciaResponsable;
    }

    public NivelClasificacion getNivelClasificacion() {
        return nivelClasificacion;
    }
    
    
    public String getDescripcion() {
        return "codigo=" + getCodigo() + ", agencia=" + getAgenciaResponsable() + ", clasificacion=" + getNivelClasificacion();
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " [" + getDescripcion() + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ArchivoDesclasificado)) {
            return false;
        }
        ArchivoDesclasificado otra = (ArchivoDesclasificado) obj;
        return codigo.equals(otra.getCodigo()) && getAgenciaResponsable().equals(otra.getAgenciaResponsable());
    }

    @Override
    public int hashCode() {
        return (getCodigo() + getAgenciaResponsable()).hashCode();
    }
    
}
