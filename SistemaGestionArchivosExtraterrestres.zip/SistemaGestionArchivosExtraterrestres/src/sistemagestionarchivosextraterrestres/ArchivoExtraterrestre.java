package sistemagestionarchivosextraterrestres;


import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dante
 */
public class ArchivoExtraterrestre {
    
    private String nombre;
    private List<ArchivoDesclasificado> archivos = new ArrayList<>();

    public ArchivoExtraterrestre(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
    }

    /**
     * 
     * Valioda que el nombre exista
     * @param nombre 
     */
    private void validarNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del archivo no puede estar vacio");
        }
    }

    public void agregarArchivo(ArchivoDesclasificado archivo) throws ArchivoDuplicadoException {
        validarArchivoRepetido(archivo);
        archivos.add(archivo);
    }

    private void validarArchivoRepetido(ArchivoDesclasificado archivo) throws ArchivoDuplicadoException {
        for (ArchivoDesclasificado archivoEnLista : archivos) {
            if (archivoEnLista.equals(archivo)) {
                throw new ArchivoDuplicadoException(
                        "Ya existe un archivo con nombre '" + archivo.getCodigo()
                        + "' y entrenador '" + archivo.getAgenciaResponsable() + "'.");
            }
        }
    }

    public List<ArchivoDesclasificado> obtenerArchivos() {
        return archivos;
    }

    public List<ArchivoDesclasificado> filtrarPorClasificacion(NivelClasificacion nivel) {
        List<ArchivoDesclasificado> filtrados = new ArrayList<>();
        for (ArchivoDesclasificado archivo : archivos) {
            if (archivo.getNivelClasificacion() == nivel) {
                filtrados.add(archivo);
            }
        }
        return filtrados;
    }
    
    
    
    
    
    
    
}
