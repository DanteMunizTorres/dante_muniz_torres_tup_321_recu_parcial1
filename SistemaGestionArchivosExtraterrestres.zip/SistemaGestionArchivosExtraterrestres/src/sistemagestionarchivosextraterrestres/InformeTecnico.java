package sistemagestionarchivosextraterrestres;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Dante
 */
public interface InformeTecnico {
    
    String generarInforme();
}
