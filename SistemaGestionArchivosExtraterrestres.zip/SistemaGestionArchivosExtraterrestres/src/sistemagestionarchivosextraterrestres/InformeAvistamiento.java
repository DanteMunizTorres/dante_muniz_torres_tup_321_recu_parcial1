/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package sistemagestionarchivosextraterrestres;
/**
 *
 * @author Dante
 */
public class InformeAvistamiento extends EvidenciaTecnica {
    
    private String ubicacion;

    public InformeAvistamiento(String codigo, String agenciaResponsable, NivelClasificacion nivelClasificacion, String fecha, double nivelConfiabilidad,String ubicacion) {
        super(codigo, agenciaResponsable, nivelClasificacion, fecha, nivelConfiabilidad);
        this.ubicacion = ubicacion;
    }
    
    
}
