/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestionarchivosextraterrestres;

import java.util.List;
import java.util.Objects;

/**
 *
 * @author Dante
 */
public class SistemaGestionArchivosExtraterrestres {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
        ArchivoExtraterrestre archivo = new ArchivoExtraterrestre("Proyecto Disclosure"); 
        try { 
            archivo.agregarArchivo( 
                new InformeAvistamiento("UAP-101", "AARO", 
                NivelClasificacion.ULTRASECRETO, "14/07/2024", 92, "Desierto de Nevada")); 

            archivo.agregarArchivo( 
                new RegistroSensor("SEN-205", "Fuerza Aerea", 
                NivelClasificacion.RESERVADO, "03/09/2023", 78, 1420.5)); 

            archivo.agregarArchivo( 
                new TestimonioClasificado("TES-308", "CIA", 
                NivelClasificacion.PUBLICO, "Testigo Orion")); 

            archivo.agregarArchivo( 
                new RegistroSensor("SEN-410", "AARO", 
                NivelClasificacion.ULTRASECRETO, "21/02/2025", 96, 3150.8)); 

            archivo.agregarArchivo( 
                new InformeAvistamiento("UAP-101", "AARO", 
                NivelClasificacion.RESERVADO, "10/10/2025", 65, "Roswell")); 
 
        } catch (ArchivoDuplicadoException e) { 
            System.out.println("No se pudo agregar el archivo: " + e.getMessage()); 
        } 
 
        System.out.println("Archivos registrados:"); 
        mostrarArchivos(archivo.obtenerArchivos()); 
 
        System.out.println(); 
 
        int analizables = analizarArchivos(archivo.obtenerArchivos()); 
 
        System.out.println("Cantidad de archivos analizables: " + analizables); 
 
        System.out.println(); 
 
        int informes = generarInformes(archivo.obtenerArchivos()); 
 
        System.out.println("Cantidad de informes generados: " + informes); 
 
        System.out.println(); 
 
        System.out.println("Archivos ULTRASECRETOS:"); 
 
        
        mostrarArchivos(archivo.filtrarPorClasificacion(NivelClasificacion.ULTRASECRETO)); 
    } 
 
    private static void mostrarArchivos( 
            List<ArchivoDesclasificado> archivos) { 
 
        if (archivos.isEmpty()) { 
            System.out.println("No hay archivos para mostrar."); 
            return; 
        } 
 
        for (ArchivoDesclasificado archivo : archivos) { 
            Objects.requireNonNull(archivo); 
            System.out.println(archivo); 
        } 
 
    } 
 
    private static int analizarArchivos( 
            List<ArchivoDesclasificado> archivos) { 
 
        int cantidad = 0; 
 
        for (ArchivoDesclasificado archivo : archivos) { 
            Objects.requireNonNull(archivo); 
 
            if (archivo instanceof EvidenciaTecnica analizable) { 
                System.out.println(analizable.generarAnalisis()); 
                cantidad++; 
            } else { 
                System.out.println("El archivo '" + archivo.getCodigo() + "' no puede analizarse como " + "evidencia tecnica."); 
            } 
        } 
        return cantidad; 
    } 
 
    private static int generarInformes( 
            List<ArchivoDesclasificado> archivos) { 
 
        int cantidad = 0; 
 
        for (ArchivoDesclasificado archivo : archivos) { 
            Objects.requireNonNull(archivo); 
 
            if (archivo instanceof InformeTecnico informable) { 
                System.out.println(informable.generarInforme()); 
                cantidad++; 
            } else { 
                System.out.println("El archivo '" + archivo.getCodigo() + "' no genera informe."); 
            } 
        } 
        return cantidad; 
    } 
    
}
