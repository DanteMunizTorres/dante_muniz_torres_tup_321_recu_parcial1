/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package sistemagestionarchivosextraterrestres;

/**
 *
 * @author Dante
 */
public class EvidenciaTecnica extends ArchivoDesclasificado {
    
    final static double CONFIABILIDAD_MAX = 100;
    final static double CONFIABILIDAD_MIN = 0;

    private String fecha;
    private double nivelConfiabilidad;

    public EvidenciaTecnica(String codigo, String agenciaResponsable, NivelClasificacion nivelClasificacion, String fecha, double nivelConfiabilidad) {
        super(codigo, agenciaResponsable, nivelClasificacion);
        this.fecha = fecha;
        this.nivelConfiabilidad = nivelConfiabilidad;
    }
    
    
    public String generarAnalisis() {
        return this.toString();
    }
    
    

}
